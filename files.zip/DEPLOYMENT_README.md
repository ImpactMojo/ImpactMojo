# Public Choice Flagship: Deployment Guide

This bundle is the Public Choice flagship course for ImpactMojo. The course title is **Public Choice: How Collective Decisions Get Made (and Why They Fail)**. Thirteen modules, 83 lexicon terms, 79 readings, paired capstone (3,000-word memo and 8-slide deck), indigo + gold palette.

## What is in this bundle

| File | What it is | Where it goes |
|---|---|---|
| `pubchoice.html` | The course page (4,800 lines, 250 KB) | GitHub repo at `/courses/pubchoice/index.html` |
| `pubchoice-modules.json` | Module content payload (525 KB across 13 modules, 5 quiz questions each) | Supabase `modules` table, read by the `serve-course-content` edge function |
| `pubchoice-lexicon.html` | Standalone lexicon page with search and filters (1,315 lines, 83 KB) | GitHub repo at `/courses/pubchoice/lexicon.html` |
| `pubchoice-lexicon.xlsx` | Lexicon as Excel for download (18 KB, 2 sheets) | Dropbox folder, link from hero buttons. **Not committed to the repo.** |
| `pubchoice-og.jpg` | OG card 1200×630 (98 KB) | GitHub repo at `/assets/images/pubchoice-og.jpg` |
| `pubchoice-og@2x.jpg` | OG card 2400×1260 retina (262 KB) | Optional, same folder as 1x |
| `pubchoice-hero.svg` | Decision-tree hero illustration (12 KB) | GitHub repo at `/courses/pubchoice/hero.svg` if used in the page |
| `impactmojoideaspipeline.xlsx` | Updated pipeline tracker | Replace the existing file at the project root |

## Answers to your specific questions

### "Do you want me to put all these files into a folder on GitHub?"

**Yes, follow the existing pattern.** Looking at the live repo, every flagship is a folder under `/courses/` containing `index.html` (the course page) and `lexicon.html` (the standalone lexicon app). Verified by inspection:

```
/courses/devecon/
  index.html        143 KB
  lexicon.html       65 KB
```

For Public Choice the same pattern applies:

```
/courses/pubchoice/
  index.html         (this is pubchoice.html, renamed)
  lexicon.html       (this is pubchoice-lexicon.html, renamed)
  hero.svg           (optional, only if you reference it in index.html)
```

The OG image goes in `/assets/images/pubchoice-og.jpg` and is referenced from the OG meta tags in `index.html`.

### "Lexicon goes in Dropbox right?"

The Excel lexicon goes in Dropbox. Confirmed by inspecting the live repo at `/courses/devecon/`, which contains only `index.html` and `lexicon.html` and no XLSX file. The XLSX is too heavy and too version-y to live in the repo; Dropbox is the right place. The hero of `pubchoice.html` already has a button that links to a Dropbox URL, currently set to a placeholder you will need to replace.

The HTML lexicon is different. That is the searchable, filterable lexicon page that lives at `/courses/pubchoice/lexicon.html`. It is the user-facing reading version of the same data; the XLSX is for download and offline use.

### "Where is the app version of the lexicon?"

This is `pubchoice-lexicon.html` in the bundle. It matches the pattern at `/courses/devecon/lexicon.html`: self-contained HTML with embedded JavaScript holding all 83 terms. Each term has term name, category, definition, applied South Asian example, source citation, module reference, and school tag. Search and 14 category filters. Theme switcher, indigo + gold palette, Inter font, Sargam icons, no emojis. Directly comparable to the DevEcon lexicon page in style and behaviour.

### "Constitution and law flagship exists. Please fact check."

**You are right.** I checked the live `/courses/` index and the directory contents on impactmojo.in. Constitution & Law is at `/courses/law/` with the title "Constitution & Law for Development Practice" and 13 modules covering: Making of the Constitution, Fundamental Rights, DPSPs & Duties, Federal Structure, Judiciary & PIL, Article 21 & Life, Social Justice, Rights-Based Laws, Criminal Justice, Environmental Law, Digital Rights, Comparative South Asia, and the Capstone.

This is the doctrinal companion to Public Choice's institutional-mechanics focus. Both touch federalism (Law M4 covers federal structure formally; Public Choice M10 covers fiscal federalism) and accountability (Law M5 covers Judiciary and PIL; Public Choice M12 covers RTI, social audit, citizen report cards). The two courses are complementary rather than overlapping; a practitioner studying Indian governance gets value from both.

Eleven flagships are live now, not nine: gandhi, devecon, dataviz, devai, mel, poa, media, sel, gender, **law**, pubpol. The pipeline xlsx in this bundle is updated to reflect this; Constitution & Law is marked Live with all 13 modules, and Public Choice is added as in-progress idea #32.

### "I don't understand what you mean by NotebookLM seeding."

I was using sloppy jargon. Here is what it actually means in plain language.

NotebookLM is Google's research tool that lets you upload a set of source documents and then ask questions of them with citations back to the source. ImpactMojo flagship courses make a NotebookLM notebook per course so users can ask the readings questions directly, in a way that searches across all the readings at once.

To set one up:

1. Go to notebooklm.google.com and sign in with the ImpactMojo account.
2. Create a new notebook. Title: "Public Choice: How Collective Decisions Get Made".
3. Upload the 79 PDFs from your Public Choice Dropbox folder as sources. (Or share the Dropbox folder with the notebook by URL if NotebookLM accepts it; PDF upload is the durable path.)
4. In the notebook settings, set sharing to "anyone with the link can view".
5. Copy the share URL.
6. Replace the placeholder string `PLACEHOLDER-PUBCHOICE-NOTEBOOK` in `pubchoice.html` with that URL.

Nothing more, no proprietary process. The hero of every flagship has a button that links to its NotebookLM, and it is one of the higher-engagement features users have flagged.

### "Basic formatting and design consistency / white font on pale pink background is not visible."

Found and fixed. The bug was a set of CSS variables (`--indigo`, `--cyan`, `--orange`, `--success`, `--callout-yellow`, etc.) that were referenced throughout the stylesheet but never defined in the `:root` block. When a CSS variable is undefined, the property falls back to its initial value, which for `background` is `transparent`. So elements like the quiz number circle (`<span class="question-number">1</span>` styled with `background: var(--indigo); color: white;`) rendered as white text on a transparent background, sitting on top of a pale card surface. Visually that read as faint or missing text.

The fix added a CSS variable shim block to `pubchoice.html` that defines all the missing variables in both light and dark mode, plus `!important` declarations on the four problematic selectors (`.question-number`, `.check-answer-btn`, `.capstone-icon`, `.phase-number`) to guarantee an indigo background and white text regardless of theme.

Stale counts also corrected. The lexicon section was hardcoded to "80 Terms"; it now reads "83 Terms" everywhere. The resources section was hardcoded to "75 readings, 33 essential"; it now reads "79 readings, 50 essential" with the per-section breakdown regenerated from the JSON.

DevEcon shares the same latent variable-shim bug. It surfaces less visibly there because the cyan + indigo palette has different incidental contrast properties. Worth fixing in DevEcon too in a separate pass.

## Three placeholders to replace before deploy

`pubchoice.html` contains three placeholder strings that need real URLs:

```
PLACEHOLDER-PUBCHOICE-READINGS    →  Dropbox URL for the folder of 79 readings
PLACEHOLDER-PUBCHOICE-NOTEBOOK    →  NotebookLM share URL (see step-by-step above)
PLACEHOLDER-PUBCHOICE-LEXICON     →  Dropbox URL for the pubchoice-lexicon.xlsx file
```

Find them with:

```bash
grep -n PLACEHOLDER pubchoice.html
```

Replace with `sed` or by hand. They are all in the hero button group near the top of the file.

## Module depth audit

Final per-module sizes:

| Module | Title | Content | Quiz | Total |
|---|---|---|---|---|
| 1 | The Public Choice Lens | 27.8 KB | 7.4 KB | 35.2 KB |
| 2 | Voting and Social Choice | 28.2 KB | 7.3 KB | 35.5 KB |
| 3 | Collective Action and Group Logic | 29.6 KB | 7.8 KB | 37.3 KB |
| 4 | Rent-Seeking and Regulatory Capture | 31.1 KB | 7.6 KB | 38.8 KB |
| 5 | Bureaucracy and Principal-Agent Problems | 33.6 KB | 7.8 KB | 41.3 KB |
| 6 | Distributive Politics and Clientelism | 33.3 KB | 8.0 KB | 41.3 KB |
| 7 | Commons Governance (Ostrom) | 34.2 KB | 7.5 KB | 41.7 KB |
| 8 | The IAD Framework | 34.7 KB | 7.3 KB | 42.0 KB |
| 9 | Constitutional Political Economy and NIE | 35.4 KB | 7.9 KB | 43.3 KB |
| 10 | Fiscal Federalism | 35.1 KB | 8.3 KB | 43.3 KB |
| 11 | Public Goods, Clubs, and Exit-Voice | 34.0 KB | 7.6 KB | 41.6 KB |
| 12 | Information and Accountability | 34.4 KB | 8.1 KB | 42.5 KB |
| 13 | Capstone Diagnostic | 34.6 KB | 8.0 KB | 42.6 KB |

Average: 33.0 KB content, 7.8 KB quiz, 40.7 KB total per module. Well beyond the DevEcon benchmark of around 20 KB per module.

Each module has the standard structure: section intro, one or more concept boxes, a coach callout (alternating Varna and Vandana Soni, capstone module features both), 2 or 3 South Asian case studies with named scholars and dated citations, a comparison grid where appropriate, callouts for nuance, a reading guidance box, and 5 quiz questions with explanations. Specific cases I drew on heavily: Muralidharan-Niehaus-Sukhtankar 2016 AER on Andhra Pradesh Smartcards, Bina Agarwal 2010 on Nepal forest user groups, Stokes-Dunning-Nazareno-Brusco 2013 on clientelism, Vaishnav 2017 on Indian electoral politics, Khan 2010/2018 on political settlements, Banerjee-Iyer 2005 on zamindari persistence, Sundar 2016 on Indian JFM, Kapur-Vaishnav on Indian political finance, the Pakistan 2020 sugar inquiry report, Samuel Paul on citizen report cards, the World Bank WDR 2004 on accountability routes.

## Lexicon depth audit

83 terms across 13 module categories:

```
Foundations (M1)                 4 terms
Voting & Social Choice (M2)      8 terms
Collective Action (M3)           5 terms
Rent-Seeking & Capture (M4)      5 terms
Bureaucracy (M5)                 3 terms
Distributive Politics (M6)       5 terms
Commons / Ostrom (M7)            6 terms
IAD Framework (M8)              11 terms
Constitutional & NIE (M9)       10 terms
Fiscal Federalism (M10)          8 terms
Public Goods & Clubs (M11)       5 terms
Accountability (M12)             8 terms
Capstone Tools (M13)             5 terms
                                ──
                                83 terms
```

Each entry has: term name, definition, applied South Asian example, source attribution, module reference, school tag (Virginia / Bloomington / NIE / Applied). The HTML app version exposes search and category filtering; the XLSX version exposes the same data plus an Index sheet with counts by school and module.

## Style audit

Final audit on the merged module content, the inline lexicon and resources sections, and the lexicon HTML app:

- 0 banned words from the user's list (delve, certainly, utilise, leverage, robust, streamline, harness, foster, underscore, enhance, testament, pivotal, intricate, crucial, transformative, groundbreaking, tapestry, paradigm, synergy, etc.)
- 0 em-dashes (all replaced with semi-colons, commas, or sentence breaks)
- 0 mojibake instances (UTF-8 double-encoding artifacts)
- 0 undefined CSS variables after the shim
- 0 emojis (Sargam icons CDN exclusively)
- "Varna" and "Vandana Soni" first names only, never "Dr."
- Coach alternation respected: M1, 3, 5, 7, 9, 11 → Varna; M2, 4, 6, 8, 10, 12 → Vandana Soni; M13 → both

## Deployment steps

1. Add the new course directory:
   ```bash
   cd ImpactMojo
   mkdir -p courses/pubchoice
   cp /path/to/pubchoice.html courses/pubchoice/index.html
   cp /path/to/pubchoice-lexicon.html courses/pubchoice/lexicon.html
   cp /path/to/pubchoice-hero.svg courses/pubchoice/hero.svg
   ```

2. Add the OG image:
   ```bash
   cp /path/to/pubchoice-og.jpg assets/images/pubchoice-og.jpg
   ```

3. Upload `pubchoice-lexicon.xlsx` to the ImpactMojo Dropbox in a folder called `pubchoice/` and copy the share URL.

4. Upload the 79 readings to the same Dropbox folder. Copy the folder share URL.

5. Create the NotebookLM notebook (steps in the section above). Copy the share URL.

6. In `courses/pubchoice/index.html`, find and replace the three placeholders:
   ```bash
   sed -i 's|PLACEHOLDER-PUBCHOICE-READINGS|<paste readings folder URL>|g' courses/pubchoice/index.html
   sed -i 's|PLACEHOLDER-PUBCHOICE-NOTEBOOK|<paste NotebookLM URL>|g' courses/pubchoice/index.html
   sed -i 's|PLACEHOLDER-PUBCHOICE-LEXICON|<paste XLSX direct download URL>|g' courses/pubchoice/index.html
   ```

7. Upload `pubchoice-modules.json` content into the Supabase `modules` table for `course_id = 'pubchoice'`. Each module is one row. The `serve-course-content` edge function will serve them by module number to the live page.

8. Add a card for Public Choice on the `/courses/` index page, matching the pattern used for the existing 11 flagships.

9. Commit and push:
   ```bash
   git add courses/pubchoice/ assets/images/pubchoice-og.jpg
   git commit -m "Add Public Choice flagship course"
   git push origin main
   ```

10. GitHub Pages will rebuild automatically. Verify at `https://www.impactmojo.in/courses/pubchoice/`.

## Open items for follow-up (not blocking deploy)

- DevEcon has the same CSS variable shim issue. A separate small PR can apply the same fix to `/courses/devecon/index.html`. Same likely applies to other flagships using the same scaffold; worth a search-and-replace audit.
- The lexicon HTML app uses 13 category colours that pass contrast against light backgrounds. Dark mode renders fine but the category tag colours could use a separate dark-mode override for stronger contrast; flag for a future polish pass.
- Five quiz questions per module is the new standard for this course; if other flagships average 3, a parity pass on those is worth scheduling.
